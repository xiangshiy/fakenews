

import math
import os
import pickle

import h5py
import jieba
import jieba.analyse as analyse
import numpy as np
import pandas as pd
import torch
from scipy.spatial import distance
from sklearn import preprocessing
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.feature_extraction.text import TfidfVectorizer
from torch.utils.data import Dataset
from transformers import BertTokenizer

class SVFENDDataset(Dataset):

    def __init__(self):
        
        with open('code_/data/dict_vid_audioconvfea.pkl', "rb") as fr:
            self.dict_vid_convfea = pickle.load(fr)
        print('load dict_vid_convfea done!')


if __name__ == "__main__":
    dataset = SVFENDDataset()
    print(dataset.dict_vid_convfea)
    print("done!")